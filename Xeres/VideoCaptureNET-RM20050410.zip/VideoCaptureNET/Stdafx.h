// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

// RM 20041221 prevent WinSock1 from being included
#define _WINSOCKAPI_